﻿
namespace v2rayN.Mode
{
    public enum EMove
    {
        Top = 1,
        Up = 2,
        Down = 3,
        Bottom = 4
    }
}
